using System;
using MPersist.Core;
using MPersist.Core.Attributes;
using MPersist.Core.Data;
using MPersist.Core.Enums;

namespace $rootnamespace$
{
    public class $safeitemname$ : AbstractViewedData
    {
        private static Logger Log = Logger.GetInstance(typeof($safeitemname$));

        #region Variable Declarations



        #endregion

        #region Viewed Properties



        #endregion
        
        #region Other Properties
	
	
	
        #endregion

        #region Constructors

	    public $safeitemname$()
	    {
	    }

	    public $safeitemname$(Session session, Persistence persistence) : base(session, persistence)
	    {
        }

        #endregion        

        #region Private Methods



        #endregion

        #region Public Methods



        #endregion
    }

    public class $safeitemname$s : AbstractViewedDataList<$safeitemname$>
    {
        private static Logger Log = Logger.GetInstance(typeof($safeitemname$s));

        #region Variable Declarations



        #endregion

        #region Properties



        #endregion

        #region Constructors

        public $safeitemname$s()
        {
        }

        #endregion

        #region Private Methods



        #endregion

        #region Public Methods



        #endregion
    }
}