using System;
using System.Collections.Generic;
using MPersist.Core;

namespace $rootnamespace$
{
    public class $safeitemname$
    {
        private static Logger Log = Logger.GetInstance(typeof($safeitemname$));

        #region Variable Declarations



        #endregion

        #region Properties



        #endregion

        #region Constructors



        #endregion

        #region Private Methods



        #endregion

        #region Public Methods



        #endregion
    }
}
