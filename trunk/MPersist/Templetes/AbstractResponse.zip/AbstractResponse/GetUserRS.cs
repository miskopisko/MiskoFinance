using MPersist.Core;
using MPersist.Core.Message.Response;

namespace $rootnamespace$
{
    public class $safeitemname$ : AbstractResponse
    {
        private static Logger Log = Logger.GetInstance(typeof($safeitemname$));

        #region Parameters

        

        #endregion
        
        #region Constructor

        public $safeitemname$()
        {

        }
        
        #endregion
    }
}
