using MPersist.Core;
using MPersist.Core.Message;
using $rootnamespace$.Requests;
using $rootnamespace$.Responses;

namespace $rootnamespace$
{
    public class $safeitemname$ : AbstractMessage
    {
        private static Logger Log = Logger.GetInstance(typeof($safeitemname$));

        #region Properties

        public new $safeitemname$RQ Request { get { return ($safeitemname$RQ)base.Request; } }

        public new $safeitemname$RS Response { get { return ($safeitemname$RS)base.Response; } }

        #endregion
        
        #region Constructors
        
        public $safeitemname$()
	{
        }

        public $safeitemname$($safeitemname$RQ request, $safeitemname$RS response) : base(request, response)
        {
        }
        
        #endregion

        public override void Execute(Session session)
        {
            
        }
    }
}
