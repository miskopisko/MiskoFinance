using MPersist.Core;
using MPersist.Core.Message;
using MPersist.Core.Message.Request;
using MPersist.Core.Message.Response;
using RBridge4.Core.Message.Requests;
using RBridge4.Core.Message.Responses;

namespace $rootnamespace$
{
    public class $safeitemname$ : AbstractMessage
    {
        private static Logger Log = Logger.GetInstance(typeof($safeitemname$));

        #region Properties

        public new $safeitemname$RQ Request { get { return ($safeitemname$RQ)base.Request; } }
        public new $safeitemname$RS Response { get { return ($safeitemname$RS)base.Response; } }

        #endregion
        
        #region Constructors
        
        public $safeitemname$()
	{
        }

        public $safeitemname$($safeitemname$RQ request, $safeitemname$RS response) : base(request, response)
        {
        }
        
        #endregion

        public override void Execute(Session session)
        {            
        }
    }
}

namespace $rootnamespace$.Requests
{
    public class $safeitemname$RQ : AbstractRequest
    {
        private static Logger Log = Logger.GetInstance(typeof($safeitemname$RQ));

        #region Parameters

        

        #endregion
        
        #region Constructor
        
        public $safeitemname$RQ()
        {
        }
        
        #endregion
    }
}

namespace $rootnamespace$.Responses
{
    public class $safeitemname$RS : AbstractResponse
    {
        private static Logger Log = Logger.GetInstance(typeof($safeitemname$RS));

        #region Parameters

        

        #endregion
        
        #region Constructor

        public $safeitemname$RS()
        {
        }
        
        #endregion
    }
}