using System;
using MPersist.Core.Data;

namespace $rootnamespace$
{
    public class $safeitemname$ : AbstractViewedData
    {
        private static Logger Log = Logger.GetInstance(typeof($safeitemname$));

        #region Variable Declarations



        #endregion

        #region Viewed Properties



        #endregion
        
        #region Other Properties
	
	
	
        #endregion

        #region Constructors

	public $safeitemname$()
	{
	}

	public $safeitemname$(Session session, Persistence persistence) : base(session, persistence)
	{
        }

        #endregion        

        #region Private Methods



        #endregion

        #region Public Methods



        #endregion
    }
}
