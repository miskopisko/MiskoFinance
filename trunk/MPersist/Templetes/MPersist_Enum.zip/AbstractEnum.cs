using System;

namespace MPersist.Resources.Enums
{
	public class $safeitemname$ : AbstractEnum
	{	
		#region Variable Declarations

        	private static readonly $safeitemname$ mNULL_ = new $safeitemname$(-1, "", "");
        
		private static readonly $safeitemname$[] mElements_ = new[]
		{
		    mNULL_
		};

		#endregion

		#region Parameters

		public static $safeitemname$[] Elements { get { return mElements_; } }		
		public static $safeitemname$ NULL { get { return mNULL_; } }

		#endregion

		protected $safeitemname$(Int64 value, String code, String description) : base(value, code, description)
		{
		}

		public static $safeitemname$ GetElement(long index)
		{
		    for (int i = 0; Elements != null && i < Elements.Length; i++)
		    {
			if (Elements[i].Value == index)
			{
			    return Elements[i];
			}
		    }

		    return null;
		}
        
		public static $safeitemname$ GetElement(String descriptionCode)
		{
		    for (int i = 0; descriptionCode != null && Elements != null && i < Elements.Length; i++)
		    {
			if (Elements[i].Description.ToLower().Equals(descriptionCode.ToLower()) || Elements[i].Code.ToLower().Equals(descriptionCode.ToLower()))
			{
			    return Elements[i];
			}
		    }

		    return null;
		}
	}
}
