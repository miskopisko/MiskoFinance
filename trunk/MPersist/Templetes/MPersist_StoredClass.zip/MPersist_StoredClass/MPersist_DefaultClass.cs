using System;
using MPersist.Core.Data;
using MPersist.Core.Enums;

namespace $rootnamespace$
{
    public class $safeitemname$ : AbstractStoredData
    {
        private static Logger Log = Logger.GetInstance(typeof($safeitemname$));

        #region Variable Declarations



        #endregion

        #region Stored Properties



        #endregion
        
        #region Other Properties
	
	
	
        #endregion

        #region Constructors

	public $safeitemname$()
	{
	}

	public $safeitemname$(Session session, Persistence persistence) : base(session, persistence)
	{
        }

        #endregion
        
        #region Override Methods
	
	public override void PreSave(Session session, UpdateMode mode)
	{
	}

	public override void PostSave(Session session, UpdateMode mode)
	{
	}
	
        #endregion

        #region Private Methods



        #endregion

        #region Public Methods



        #endregion
    }
}
