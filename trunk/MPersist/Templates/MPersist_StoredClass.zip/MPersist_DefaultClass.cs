using System;
using MPersist.Core;
using MPersist.Core.Attributes;
using MPersist.Core.Data;
using MPersist.Core.Enums;

namespace $rootnamespace$
{
    public class $safeitemname$ : AbstractStoredData
    {
        private static Logger Log = Logger.GetInstance(typeof($safeitemname$));

        #region Fields



        #endregion

        #region Stored Properties



        #endregion
        
        #region Other Properties
	
	
	
        #endregion

        #region Constructors

	    public $safeitemname$()
	    {
	    }

	    public $safeitemname$(Session session, Persistence persistence) : base(session, persistence)
	    {
        }

        #endregion
        
        #region Override Methods
	
	    public override void PreSave(Session session, UpdateMode mode)
	    {
	    }

	    public override void PostSave(Session session, UpdateMode mode)
	    {
	    }
	
        #endregion

        #region Private Methods



        #endregion

        #region Public Methods



        #endregion
    }

    public class $safeitemname$s : AbstractStoredDataList<$safeitemname$>
    {
        private static Logger Log = Logger.GetInstance(typeof($safeitemname$s));

        #region Fields



        #endregion

        #region Properties



        #endregion

        #region Constructors

        public $safeitemname$s()
        {
        }

        #endregion

        #region Private Methods



        #endregion

        #region Public Methods



        #endregion
    }
}
