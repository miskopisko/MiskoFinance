using System;
using MPersist.Core;
using MPersist.Core.Attributes;
using MPersist.Core.Data;

namespace $rootnamespace$
{
    public class $safeitemname$ : StoredData
    {
        private static Logger Log = Logger.GetInstance(typeof($safeitemname$));

        #region Fields

	

        #endregion

        #region Stored Properties

	

        #endregion
        
        #region Other Properties
	
	
	
        #endregion

        #region Constructors

	public $safeitemname$()
	{
	}

	public $safeitemname$(Session session, Persistence persistence) : base(session, persistence)
	{
        }

        #endregion
        
        #region Override Methods
	
	
	
        #endregion

        #region Private Methods

	

        #endregion

        #region Public Methods

	

        #endregion
    }
}
