using MPersist.Core;
using MPersist.Core.Message.Request;

namespace $rootnamespace$
{
    public class $safeitemname$ : AbstractRequest
    {
        private static Logger Log = Logger.GetInstance(typeof($safeitemname$));

        #region Parameters

        

        #endregion
        
        #region Constructor
        
        public $safeitemname$()
        {
        }
        
        #endregion
    }
}
